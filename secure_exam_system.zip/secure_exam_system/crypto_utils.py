import os
import hashlib
import random
import string
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

def generate_meaningful_key() -> str:
    """Generates a human-readable, meaningful key with secure random entropy."""
    # Creates an 8-character random secure suffix
    chars = string.ascii_uppercase + string.digits
    random_suffix = ''.join(random.choices(chars, k=8))
    
    # You can customize the prefix to whatever your exam subject is!
    return f"EXAM-MATH-2026-{random_suffix}"

def derive_aes_key(passphrase: str) -> bytes:
    """Secretly converts the readable text into a raw 32-byte (256-bit) AES key."""
    return hashlib.sha256(passphrase.encode('utf-8')).digest()

def encrypt_data(data: bytes) -> tuple:
    # 1. Generate the readable passphrase
    passphrase = generate_meaningful_key()
    
    # 2. Derive the mathematical AES key from it
    aes_key = derive_aes_key(passphrase)
    aesgcm = AESGCM(aes_key)
    
    # 3. Encrypt the data
    nonce = os.urandom(12)
    ciphertext = aesgcm.encrypt(nonce, data, None)
    
    # Return the ciphertext and the READABLE key to the Admin
    return nonce + ciphertext, passphrase

def decrypt_data(encrypted_payload: bytes, passphrase: str) -> bytes:
    # 1. Convert the student's entered readable key back into the AES format
    aes_key = derive_aes_key(passphrase)
    aesgcm = AESGCM(aes_key)
    
    # 2. Extract nonce and ciphertext
    nonce = encrypted_payload[:12]
    ciphertext = encrypted_payload[12:]
    
    # 3. Decrypt
    return aesgcm.decrypt(nonce, ciphertext, None)