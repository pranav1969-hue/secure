import os
from flask import Flask, request, jsonify, render_template_string
from crypto_utils import encrypt_data

app = Flask(__name__)
DATA_DIR = "data"
os.makedirs(DATA_DIR, exist_ok=True)
ENC_FILE = os.path.join(DATA_DIR, "staged_exam.enc")

# The isolated Frontend UI just for the Examiner
EXAMINER_HTML = """
<!DOCTYPE html>
<html>
<head>
    <title>Examiner Node - Secure Exam System</title>
    <style>
        body { font-family: Arial, sans-serif; background: #eef2f5; padding: 20px; }
        .container { max-width: 700px; margin: auto; background: white; padding: 30px; border-radius: 8px; box-shadow: 0 4px 8px rgba(0,0,0,0.1); }
        h1 { color: #0056b3; border-bottom: 2px solid #ddd; padding-bottom: 10px; }
        .box { padding: 15px; border: 1px solid #ccc; border-radius: 5px; background: #fafafa; margin-top: 20px; }
        input[type="file"] { width: 100%; padding: 10px; margin-top: 10px; box-sizing: border-box; }
        button { background: #007bff; color: white; border: none; padding: 12px 20px; margin-top: 15px; cursor: pointer; border-radius: 4px; font-size: 16px; font-weight: bold; width: 100%; }
        button:hover { background: #0056b3; }
        #key-display { font-family: monospace; font-size: 1.5em; color: #d9534f; background: #f9f2f4; padding: 15px; margin-top: 10px; border-radius: 4px; text-align: center; border: 1px solid #ebccd1; letter-spacing: 2px; }
    </style>
</head>
<body>
    <div class="container">
        <h1>👨‍🏫 Examiner Node</h1>
        <p>Upload the raw exam PDF. It will be encrypted into ciphertext and staged for student nodes.</p>
        
        <div class="box">
            <input type="file" id="exam-file" accept="application/pdf">
            <button onclick="uploadExam()">Encrypt & Stage PDF</button>
            
            <div id="admin-result" style="display:none; margin-top: 20px;">
                <h3 style="color: #28a745; text-align: center;">✅ Encryption Successful!</h3>
                <p style="text-align: center;">Share this passphrase with students ONLY when the exam begins:</p>
                <div id="key-display"></div>
            </div>
        </div>
    </div>

    <script>
        async function uploadExam() {
            const fileInput = document.getElementById('exam-file');
            if(!fileInput.files[0]) return alert("Please select a PDF file.");
            
            const formData = new FormData();
            formData.append('file', fileInput.files[0]);
            
            const btn = document.querySelector('button');
            btn.innerText = "Encrypting...";
            btn.disabled = true;

            try {
                const response = await fetch('/api/upload', { method: 'POST', body: formData });
                const result = await response.json();
                if(response.ok) {
                    document.getElementById('admin-result').style.display = 'block';
                    document.getElementById('key-display').innerText = result.key;
                } else {
                    alert("Error: " + result.error);
                }
            } catch (e) {
                alert("Server error.");
            } finally {
                btn.innerText = "Encrypt & Stage PDF";
                btn.disabled = false;
            }
        }
    </script>
</body>
</html>
"""

@app.route('/')
def index():
    return render_template_string(EXAMINER_HTML)

@app.route('/api/upload', methods=['POST'])
def upload():
    if 'file' not in request.files:
        return jsonify({"error": "No file uploaded"}), 400
    
    file = request.files['file']
    data = file.read()
    
    if not data:
        return jsonify({"error": "Empty file"}), 400

    # Encrypt and get the readable passphrase
    ciphertext, passphrase = encrypt_data(data)
    
    # Save the locked payload
    with open(ENC_FILE, 'wb') as f:
        f.write(ciphertext)
        
    return jsonify({"key": passphrase, "message": "Encrypted and Staged."})

if __name__ == '__main__':
    print("\n👨‍🏫 EXAMINER MODULE RUNNING ON PORT 5000")
    app.run(debug=True, port=5000)