import os
import io
from flask import Flask, request, jsonify, send_file, render_template_string
from crypto_utils import decrypt_data

app = Flask(__name__)
DATA_DIR = "data"
ENC_FILE = os.path.join(DATA_DIR, "staged_exam.enc")

# The isolated Frontend UI just for the Student
STUDENT_HTML = """
<!DOCTYPE html>
<html>
<head>
    <title>Student Node - Secure Exam System</title>
    <style>
        body { font-family: Arial, sans-serif; background: #fdfdfd; padding: 20px; }
        .container { max-width: 900px; margin: auto; background: white; padding: 30px; border-radius: 8px; box-shadow: 0 4px 8px rgba(0,0,0,0.1); }
        h1 { color: #28a745; border-bottom: 2px solid #ddd; padding-bottom: 10px; }
        .box { padding: 15px; border: 1px solid #ccc; border-radius: 5px; background: #fafafa; margin-top: 20px; }
        input[type="text"] { width: 100%; padding: 15px; margin-top: 10px; box-sizing: border-box; font-size: 1.2em; text-align: center; letter-spacing: 1px;}
        button { background: #28a745; color: white; border: none; padding: 15px 20px; margin-top: 15px; cursor: pointer; border-radius: 4px; font-size: 16px; font-weight: bold; width: 100%; }
        button:hover { background: #218838; }
        iframe { width: 100%; height: 750px; border: 1px solid #ccc; margin-top: 20px; background: #ebebeb; }
        #timer { font-size: 1.8em; font-weight: bold; color: #d9534f; text-align: center; margin-top: 10px; }
        #setup-area { transition: opacity 0.5s; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🎓 Student Node (Live Exam)</h1>
        
        <div id="setup-area" class="box">
            <p style="text-align: center; font-size: 1.1em;">Enter the secure passphrase provided by the examiner to decrypt the paper and begin the exam timer.</p>
            <input type="text" id="exam-key" placeholder="e.g., EXAM-MATH-2026-A1B2C3D4">
            <button onclick="unlockExam()">Verify Passphrase & Start Exam</button>
            <div id="student-error" style="color: red; font-weight: bold; margin-top: 15px; text-align: center;"></div>
        </div>
        
        <div id="exam-environment" style="display:none; margin-top: 20px;">
            <div id="timer">⏳ Time Remaining: <span id="time">60:00</span></div>
            <iframe id="pdf-viewer"></iframe>
        </div>
    </div>

    <script>
        async function unlockExam() {
            const key = document.getElementById('exam-key').value.trim();
            if(!key) return alert("Please enter the decryption passphrase.");

            const btn = document.querySelector('button');
            btn.innerText = "Decrypting & Validating...";
            btn.disabled = true;
            document.getElementById('student-error').innerText = '';

            try {
                const response = await fetch('/api/unlock', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ key })
                });

                if(response.ok) {
                    const blob = await response.blob();
                    const objectUrl = URL.createObjectURL(blob);
                    
                    document.getElementById('setup-area').style.display = 'none';
                    document.getElementById('exam-environment').style.display = 'block';
                    document.getElementById('pdf-viewer').src = objectUrl + "#toolbar=0&navpanes=0&scrollbar=0";
                    startTimer(3600); // 60 minutes
                } else {
                    const result = await response.json();
                    document.getElementById('student-error').innerText = "❌ " + (result.error || "Decryption failed. Invalid passphrase.");
                }
            } catch (e) {
                document.getElementById('student-error').innerText = "❌ Network or Server Error.";
            } finally {
                btn.innerText = "Verify Passphrase & Start Exam";
                btn.disabled = false;
            }
        }

        function startTimer(duration) {
            let timer = duration, minutes, seconds;
            const display = document.getElementById('time');
            const interval = setInterval(function () {
                minutes = parseInt(timer / 60, 10);
                seconds = parseInt(timer % 60, 10);
                minutes = minutes < 10 ? "0" + minutes : minutes;
                seconds = seconds < 10 ? "0" + seconds : seconds;
                display.textContent = minutes + ":" + seconds;
                if (--timer < 0) {
                    clearInterval(interval);
                    display.textContent = "00:00 (EXAM OVER)";
                    document.getElementById('pdf-viewer').src = "";
                    alert("Time is up! The exam paper has been purged from memory.");
                }
            }, 1000);
        }
    </script>
</body>
</html>
"""

@app.route('/')
def index():
    return render_template_string(STUDENT_HTML)

@app.route('/api/unlock', methods=['POST'])
def unlock():
    passphrase = request.json.get('key')
    if not passphrase or not os.path.exists(ENC_FILE):
        return jsonify({"error": "Missing key or payload not staged"}), 400
        
    try:
        # Read the locked payload from disk
        with open(ENC_FILE, 'rb') as f:
            encrypted_payload = f.read()
            
        # Decrypt in memory using the updated crypto_utils
        plaintext_pdf = decrypt_data(encrypted_payload, passphrase)
        
        return send_file(
            io.BytesIO(plaintext_pdf), 
            mimetype='application/pdf', 
            as_attachment=False, 
            download_name="live_exam.pdf"
        )
    except Exception as e:
        return jsonify({"error": "Cryptographic verification failed. Invalid Passphrase."}), 403

if __name__ == '__main__':
    print("\n🎓 STUDENT MODULE RUNNING ON PORT 5001")
    app.run(debug=True, port=5001)