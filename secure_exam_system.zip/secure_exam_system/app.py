import os
import io
from flask import Flask, request, jsonify, send_file, render_template_string
from crypto_utils import encrypt_data, decrypt_data

app = Flask(__name__)
DATA_DIR = "data"
os.makedirs(DATA_DIR, exist_ok=True)
ENC_FILE = os.path.join(DATA_DIR, "staged_exam.enc")

# --- 1. MAIN MENU HTML ---
HOME_HTML = """
<!DOCTYPE html>
<html>
<head>
    <title>Secure Exam System</title>
    <style>
        body { font-family: Arial, sans-serif; background: #eef2f5; text-align: center; padding-top: 100px; }
        .btn { display: inline-block; padding: 20px 40px; color: white; text-decoration: none; font-size: 20px; border-radius: 8px; margin: 20px; font-weight: bold; transition: 0.3s; }
        .btn-examiner { background: #007bff; }
        .btn-examiner:hover { background: #0056b3; }
        .btn-student { background: #28a745; }
        .btn-student:hover { background: #218838; }
    </style>
</head>
<body>
    <h1>🛡️ Secure Examination System</h1>
    <p>Please select your role to continue:</p>
    <a href="/examiner" class="btn btn-examiner">👨‍🏫 Go to Examiner Module</a>
    <a href="/student" class="btn btn-student">🎓 Go to Student Module</a>
</body>
</html>
"""

# --- 2. EXAMINER HTML ---
EXAMINER_HTML = """
<!DOCTYPE html>
<html>
<head>
    <title>Examiner Node</title>
    <style>
        body { font-family: Arial, sans-serif; background: #eef2f5; padding: 20px; }
        .container { max-width: 700px; margin: auto; background: white; padding: 30px; border-radius: 8px; box-shadow: 0 4px 8px rgba(0,0,0,0.1); }
        h1 { color: #0056b3; border-bottom: 2px solid #ddd; padding-bottom: 10px; }
        .box { padding: 15px; border: 1px solid #ccc; border-radius: 5px; background: #fafafa; margin-top: 20px; }
        input[type="file"] { width: 100%; padding: 10px; margin-top: 10px; box-sizing: border-box; }
        button { background: #007bff; color: white; border: none; padding: 12px 20px; margin-top: 15px; cursor: pointer; border-radius: 4px; font-size: 16px; font-weight: bold; width: 100%; }
        #key-display { font-family: monospace; font-size: 1.5em; color: #d9534f; background: #f9f2f4; padding: 15px; margin-top: 10px; border-radius: 4px; text-align: center; border: 1px solid #ebccd1; letter-spacing: 2px; }
        .back-link { text-decoration: none; color: #555; font-weight: bold; display: inline-block; margin-bottom: 20px; }
    </style>
</head>
<body>
    <div class="container">
        <a href="/" class="back-link">⬅ Back to Main Menu</a>
        <h1>👨‍🏫 Examiner Node</h1>
        <p>Upload the raw exam PDF. It will be encrypted into ciphertext and staged for student nodes.</p>
        <div class="box">
            <input type="file" id="exam-file" accept="application/pdf">
            <button onclick="uploadExam()">Encrypt & Stage PDF</button>
            <div id="admin-result" style="display:none; margin-top: 20px;">
                <h3 style="color: #28a745; text-align: center;">✅ Encryption Successful!</h3>
                <p style="text-align: center;">Share this passphrase with students ONLY when the exam begins:</p>
                <div id="key-display"></div>
            </div>
        </div>
    </div>
    <script>
        async function uploadExam() {
            const fileInput = document.getElementById('exam-file');
            if(!fileInput.files[0]) return alert("Please select a PDF file.");
            const formData = new FormData();
            formData.append('file', fileInput.files[0]);
            const btn = document.querySelector('button');
            btn.innerText = "Encrypting..."; btn.disabled = true;
            try {
                const response = await fetch('/api/upload', { method: 'POST', body: formData });
                const result = await response.json();
                if(response.ok) {
                    document.getElementById('admin-result').style.display = 'block';
                    document.getElementById('key-display').innerText = result.key;
                } else { alert("Error: " + result.error); }
            } catch (e) { alert("Server error."); } 
            finally { btn.innerText = "Encrypt & Stage PDF"; btn.disabled = false; }
        }
    </script>
</body>
</html>
"""

# --- 3. STUDENT HTML ---
STUDENT_HTML = """
<!DOCTYPE html>
<html>
<head>
    <title>Student Node</title>
    <style>
        body { font-family: Arial, sans-serif; background: #fdfdfd; padding: 20px; }
        .container { max-width: 900px; margin: auto; background: white; padding: 30px; border-radius: 8px; box-shadow: 0 4px 8px rgba(0,0,0,0.1); }
        h1 { color: #28a745; border-bottom: 2px solid #ddd; padding-bottom: 10px; }
        .box { padding: 15px; border: 1px solid #ccc; border-radius: 5px; background: #fafafa; margin-top: 20px; }
        input[type="text"] { width: 100%; padding: 15px; margin-top: 10px; box-sizing: border-box; font-size: 1.2em; text-align: center; letter-spacing: 1px;}
        button { background: #28a745; color: white; border: none; padding: 15px 20px; margin-top: 15px; cursor: pointer; border-radius: 4px; font-size: 16px; font-weight: bold; width: 100%; }
        iframe { width: 100%; height: 750px; border: 1px solid #ccc; margin-top: 20px; background: #ebebeb; }
        #timer { font-size: 1.8em; font-weight: bold; color: #d9534f; text-align: center; margin-top: 10px; }
        .back-link { text-decoration: none; color: #555; font-weight: bold; display: inline-block; margin-bottom: 20px; }
    </style>
</head>
<body>
    <div class="container">
        <a href="/" class="back-link">⬅ Back to Main Menu</a>
        <h1>🎓 Student Node (Live Exam)</h1>
        <div id="setup-area" class="box">
            <p style="text-align: center; font-size: 1.1em;">Enter the secure passphrase provided by the examiner.</p>
            <input type="text" id="exam-key" placeholder="e.g., EXAM-MATH-2026-A1B2C3D4">
            <button onclick="unlockExam()">Verify Passphrase & Start Exam</button>
            <div id="student-error" style="color: red; font-weight: bold; margin-top: 15px; text-align: center;"></div>
        </div>
        <div id="exam-environment" style="display:none; margin-top: 20px;">
            <div id="timer">⏳ Time Remaining: <span id="time">60:00</span></div>
            <iframe id="pdf-viewer"></iframe>
        </div>
    </div>
    <script>
        async function unlockExam() {
            const key = document.getElementById('exam-key').value.trim();
            if(!key) return alert("Please enter the decryption passphrase.");
            const btn = document.querySelector('button');
            btn.innerText = "Decrypting & Validating..."; btn.disabled = true;
            document.getElementById('student-error').innerText = '';
            try {
                const response = await fetch('/api/unlock', {
                    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ key })
                });
                if(response.ok) {
                    const blob = await response.blob();
                    const objectUrl = URL.createObjectURL(blob);
                    document.getElementById('setup-area').style.display = 'none';
                    document.getElementById('exam-environment').style.display = 'block';
                    document.getElementById('pdf-viewer').src = objectUrl + "#toolbar=0&navpanes=0&scrollbar=0";
                    startTimer(3600);
                } else {
                    const result = await response.json();
                    document.getElementById('student-error').innerText = "❌ " + (result.error || "Invalid passphrase.");
                }
            } catch (e) { document.getElementById('student-error').innerText = "❌ Network Error."; } 
            finally { btn.innerText = "Verify Passphrase & Start Exam"; btn.disabled = false; }
        }
        function startTimer(duration) {
            let timer = duration, minutes, seconds;
            const display = document.getElementById('time');
            const interval = setInterval(function () {
                minutes = parseInt(timer / 60, 10); seconds = parseInt(timer % 60, 10);
                minutes = minutes < 10 ? "0" + minutes : minutes; seconds = seconds < 10 ? "0" + seconds : seconds;
                display.textContent = minutes + ":" + seconds;
                if (--timer < 0) {
                    clearInterval(interval);
                    display.textContent = "00:00 (EXAM OVER)";
                    document.getElementById('pdf-viewer').src = "";
                    alert("Time is up! The exam paper has been purged from memory.");
                }
            }, 1000);
        }
    </script>
</body>
</html>
"""

# --- ROUTES ---
@app.route('/')
def index():
    return render_template_string(HOME_HTML)

@app.route('/examiner')
def examiner():
    return render_template_string(EXAMINER_HTML)

@app.route('/student')
def student():
    return render_template_string(STUDENT_HTML)

@app.route('/api/upload', methods=['POST'])
def upload():
    if 'file' not in request.files:
        return jsonify({"error": "No file uploaded"}), 400
    file = request.files['file']
    data = file.read()
    if not data:
        return jsonify({"error": "Empty file"}), 400

    ciphertext, passphrase = encrypt_data(data)
    with open(ENC_FILE, 'wb') as f:
        f.write(ciphertext)
    return jsonify({"key": passphrase, "message": "Encrypted and Staged."})

@app.route('/api/unlock', methods=['POST'])
def unlock():
    passphrase = request.json.get('key')
    if not passphrase or not os.path.exists(ENC_FILE):
        return jsonify({"error": "Missing key or payload not staged"}), 400
    try:
        with open(ENC_FILE, 'rb') as f:
            encrypted_payload = f.read()
        plaintext_pdf = decrypt_data(encrypted_payload, passphrase)
        return send_file(io.BytesIO(plaintext_pdf), mimetype='application/pdf', as_attachment=False, download_name="live_exam.pdf")
    except Exception:
        return jsonify({"error": "Cryptographic verification failed. Invalid Passphrase."}), 403

if __name__ == '__main__':
    print("\n🚀 UNIFIED EXAM SYSTEM RUNNING ON PORT 5000")
    print("Open http://127.0.0.1:5000 in your browser\n")
    app.run(debug=True, port=5000)